# Laravel-Mangas
Proyecto Laravel Mangas



Este Archico contiene mangas.rar en el cual esta el proyecto de Laravel .

Contiene el PDF de los documentos de los integrantes:
Israel Gonzalez Hernandez.
Fernando Ortiz Marin.
Luis Castillo Pineda.
